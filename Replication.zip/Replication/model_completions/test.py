import os
import pandas as pd

# Define file location
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(SCRIPT_DIR, f"xstest_v2_completions_mistrG.csv")

# Step 1: Try to read with fallback encodings
try:
    df = pd.read_csv(file_path, encoding="utf-8")
    print("✅ Read with UTF-8")
except UnicodeDecodeError:
    print("⚠️ UTF-8 failed, trying CP1252...")
    df = pd.read_csv(file_path, encoding="cp1252")
    print("✅ Read with CP1252 (Windows encoding)")

# Step 2: Re-save the same data in clean UTF-8
df.to_csv(file_path, index=False, encoding="utf-8")
print("💾 File re-saved in UTF-8. Your pipeline can now read it safely.")